import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-balance',
  templateUrl: 'balance.html'
})
export class BalancePage {

  constructor(public navCtrl: NavController) {
  }
  
}
