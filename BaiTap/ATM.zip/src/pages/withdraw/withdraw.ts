import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-withdraw',
  templateUrl: 'withdraw.html'
})
export class WithdrawPage {

  constructor(public navCtrl: NavController) {
  }
  
}
