import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TransferPage } from '../transfer/transfer';
import { BalancePage } from '../balance/balance';
import { WithdrawPage } from '../withdraw/withdraw';
import { DepositPage } from '../deposit/deposit';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {
  }
  goToTransfer(params){
    if (!params) params = {};
    this.navCtrl.push(TransferPage);
  }goToBalance(params){
    if (!params) params = {};
    this.navCtrl.push(BalancePage);
  }goToWithdraw(params){
    if (!params) params = {};
    this.navCtrl.push(WithdrawPage);
  }goToDeposit(params){
    if (!params) params = {};
    this.navCtrl.push(DepositPage);
  }
}
