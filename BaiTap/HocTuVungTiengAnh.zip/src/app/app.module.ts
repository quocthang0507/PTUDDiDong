import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HCTVNgTiNgAnhPage } from '../pages/h-ctvng-ti-ng-anh/h-ctvng-ti-ng-anh';
import { HCTVNgTheoChPage } from '../pages/h-ctvng-theo-ch/h-ctvng-theo-ch';
import { KiMTraTiNgAnhPage } from '../pages/ki-mtra-ti-ng-anh/ki-mtra-ti-ng-anh';
import { TVNgChiTiTPage } from '../pages/t-vng-chi-ti-t/t-vng-chi-ti-t';
import { ChAnimalPage } from '../pages/ch-animal/ch-animal';
import { DanhSChTrChIPage } from '../pages/danh-sch-tr-ch-i/danh-sch-tr-ch-i';
import { TrCNghiMPage } from '../pages/tr-cnghi-m/tr-cnghi-m';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    HCTVNgTiNgAnhPage,
    HCTVNgTheoChPage,
    KiMTraTiNgAnhPage,
    TVNgChiTiTPage,
    ChAnimalPage,
    DanhSChTrChIPage,
    TrCNghiMPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HCTVNgTiNgAnhPage,
    HCTVNgTheoChPage,
    KiMTraTiNgAnhPage,
    TVNgChiTiTPage,
    ChAnimalPage,
    DanhSChTrChIPage,
    TrCNghiMPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}