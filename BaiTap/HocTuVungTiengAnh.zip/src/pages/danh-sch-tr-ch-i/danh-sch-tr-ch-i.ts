import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TrCNghiMPage } from '../tr-cnghi-m/tr-cnghi-m';

@Component({
  selector: 'page-danh-sch-tr-ch-i',
  templateUrl: 'danh-sch-tr-ch-i.html'
})
export class DanhSChTrChIPage {

  constructor(public navCtrl: NavController) {
  }
  goToTrCNghiM(params){
    if (!params) params = {};
    this.navCtrl.push(TrCNghiMPage);
  }
}
