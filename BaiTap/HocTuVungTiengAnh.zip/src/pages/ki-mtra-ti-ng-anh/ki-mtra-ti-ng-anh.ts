import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-ki-mtra-ti-ng-anh',
  templateUrl: 'ki-mtra-ti-ng-anh.html'
})
export class KiMTraTiNgAnhPage {

  constructor(public navCtrl: NavController) {
  }
  
}
