import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { TVNgChiTiTPage } from '../t-vng-chi-ti-t/t-vng-chi-ti-t';
import { DanhSChTrChIPage } from '../danh-sch-tr-ch-i/danh-sch-tr-ch-i';
import { TrCNghiMPage } from '../tr-cnghi-m/tr-cnghi-m';

@Component({
  selector: 'page-ch-animal',
  templateUrl: 'ch-animal.html'
})
export class ChAnimalPage {

  constructor(public navCtrl: NavController) {
  }
  goToTVNgChiTiT(params){
    if (!params) params = {};
    this.navCtrl.push(TVNgChiTiTPage);
  }goToDanhSChTrChI(params){
    if (!params) params = {};
    this.navCtrl.push(DanhSChTrChIPage);
  }goToTrCNghiM(params){
    if (!params) params = {};
    this.navCtrl.push(TrCNghiMPage);
  }
}
