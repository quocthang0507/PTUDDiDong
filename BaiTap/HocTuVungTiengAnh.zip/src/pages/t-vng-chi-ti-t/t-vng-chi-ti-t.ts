import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-t-vng-chi-ti-t',
  templateUrl: 't-vng-chi-ti-t.html'
})
export class TVNgChiTiTPage {

  constructor(public navCtrl: NavController) {
  }
  
}
