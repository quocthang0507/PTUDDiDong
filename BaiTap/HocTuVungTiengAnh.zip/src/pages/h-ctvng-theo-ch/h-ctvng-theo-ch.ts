import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ChAnimalPage } from '../ch-animal/ch-animal';
import { TVNgChiTiTPage } from '../t-vng-chi-ti-t/t-vng-chi-ti-t';
import { DanhSChTrChIPage } from '../danh-sch-tr-ch-i/danh-sch-tr-ch-i';
import { TrCNghiMPage } from '../tr-cnghi-m/tr-cnghi-m';

@Component({
  selector: 'page-h-ctvng-theo-ch',
  templateUrl: 'h-ctvng-theo-ch.html'
})
export class HCTVNgTheoChPage {

  constructor(public navCtrl: NavController) {
  }
  goToChAnimal(params){
    if (!params) params = {};
    this.navCtrl.push(ChAnimalPage);
  }goToTVNgChiTiT(params){
    if (!params) params = {};
    this.navCtrl.push(TVNgChiTiTPage);
  }goToDanhSChTrChI(params){
    if (!params) params = {};
    this.navCtrl.push(DanhSChTrChIPage);
  }goToTrCNghiM(params){
    if (!params) params = {};
    this.navCtrl.push(TrCNghiMPage);
  }
}
