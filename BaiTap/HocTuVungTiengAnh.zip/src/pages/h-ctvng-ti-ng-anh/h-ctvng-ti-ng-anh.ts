import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HCTVNgTheoChPage } from '../h-ctvng-theo-ch/h-ctvng-theo-ch';
import { ChAnimalPage } from '../ch-animal/ch-animal';
import { TVNgChiTiTPage } from '../t-vng-chi-ti-t/t-vng-chi-ti-t';
import { DanhSChTrChIPage } from '../danh-sch-tr-ch-i/danh-sch-tr-ch-i';
import { TrCNghiMPage } from '../tr-cnghi-m/tr-cnghi-m';
import { KiMTraTiNgAnhPage } from '../ki-mtra-ti-ng-anh/ki-mtra-ti-ng-anh';

@Component({
  selector: 'page-h-ctvng-ti-ng-anh',
  templateUrl: 'h-ctvng-ti-ng-anh.html'
})
export class HCTVNgTiNgAnhPage {

  constructor(public navCtrl: NavController) {
  }
  goToHCTVNgTheoCh(params){
    if (!params) params = {};
    this.navCtrl.push(HCTVNgTheoChPage);
  }goToChAnimal(params){
    if (!params) params = {};
    this.navCtrl.push(ChAnimalPage);
  }goToTVNgChiTiT(params){
    if (!params) params = {};
    this.navCtrl.push(TVNgChiTiTPage);
  }goToDanhSChTrChI(params){
    if (!params) params = {};
    this.navCtrl.push(DanhSChTrChIPage);
  }goToTrCNghiM(params){
    if (!params) params = {};
    this.navCtrl.push(TrCNghiMPage);
  }goToKiMTraTiNgAnh(params){
    if (!params) params = {};
    this.navCtrl.push(KiMTraTiNgAnhPage);
  }
}
