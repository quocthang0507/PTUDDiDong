import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-tr-cnghi-m',
  templateUrl: 'tr-cnghi-m.html'
})
export class TrCNghiMPage {

  constructor(public navCtrl: NavController) {
  }
  
}
