import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers as TheHeaders } from '@angular/http';
import 'rxjs/add/operator/map';
import { BaseServiceProvider } from './BaseServiceProvider';


@Injectable()
export class UserProvider extends BaseServiceProvider {
    
    
}